package com.example.benshaw.myfristapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity{
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        }

    public void OptimizedMe (View view) {
        android.content.Intent Optimized_Intent = new android.content.Intent(this, Main2Activity.class);
        startActivity(Optimized_Intent);
    }
        public void DistanceMe(View view){
            android.content.Intent DistanceIntent = new android.content.Intent(this,Main3Activity.class);
            startActivity(DistanceIntent);

    }


    }

